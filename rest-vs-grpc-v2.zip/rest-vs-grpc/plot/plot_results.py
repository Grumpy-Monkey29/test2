"""
plot_results.py
Reads the four k6 result files and produces a multi-panel comparison report.

Requirements:
    pip install matplotlib numpy

Run from the project root:
    python plot/plot_results.py
"""

import json
import os
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.ticker
from pathlib import Path

matplotlib.rcParams.update({
    "font.family"      : "sans-serif",
    "axes.spines.top"  : False,
    "axes.spines.right": False,
    "axes.grid"        : True,
    "grid.alpha"       : 0.35,
    "grid.linestyle"   : "--",
})

REST_COLOR = "#4A90D9"
GRPC_COLOR = "#E8603C"

ROOT_DIR    = Path(__file__).parent.parent
RESULTS_DIR = ROOT_DIR / "results"
OUT_DIR     = ROOT_DIR / "results"
OUT_DIR.mkdir(exist_ok=True)


def load(filename):
    path = RESULTS_DIR / filename
    if not path.exists():
        print(f"[WARN] {filename} not found — skipping that panel.")
        return None
    with open(path) as f:
        return json.load(f)


def bar_group(ax, labels, rest_vals, grpc_vals, ylabel, title, fmt="{:.1f}"):
    x     = np.arange(len(labels))
    width = 0.35
    bars_rest = ax.bar(x - width / 2, rest_vals, width, label="REST",  color=REST_COLOR, zorder=3)
    bars_grpc = ax.bar(x + width / 2, grpc_vals, width, label="gRPC",  color=GRPC_COLOR, zorder=3)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=9)
    ax.set_ylabel(ylabel, fontsize=9)
    ax.set_title(title, fontsize=11, fontweight="bold", pad=8)
    ax.legend(fontsize=8)
    for bar, color in [(b, REST_COLOR) for b in bars_rest] + [(b, GRPC_COLOR) for b in bars_grpc]:
        h = bar.get_height()
        if h:
            ax.annotate(fmt.format(h),
                        xy=(bar.get_x() + bar.get_width() / 2, h),
                        xytext=(0, 3), textcoords="offset points",
                        ha="center", va="bottom", fontsize=7, color=color)


def line_plot(ax, x_vals, rest_vals, grpc_vals, xlabel, ylabel, title, x_log=False):
    ax.plot(x_vals, rest_vals, "o-", color=REST_COLOR, linewidth=2, markersize=6, label="REST", zorder=3)
    ax.plot(x_vals, grpc_vals, "s-", color=GRPC_COLOR, linewidth=2, markersize=6, label="gRPC", zorder=3)
    if x_log:
        ax.set_xscale("log")
        ax.set_xticks(x_vals)
        ax.get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
    ax.set_xlabel(xlabel, fontsize=9)
    ax.set_ylabel(ylabel, fontsize=9)
    ax.set_title(title, fontsize=11, fontweight="bold", pad=8)
    ax.legend(fontsize=8)


# ─────────────────────────────────────────────────────────────────────────────
# 4 rows × 2 cols
# ─────────────────────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(16, 20))
fig.suptitle("REST vs gRPC — Performance Comparison\n(includes JSON stringify/parse vs Protobuf encode/decode overhead)",
             fontsize=15, fontweight="bold", y=0.99)
gs = gridspec.GridSpec(4, 2, figure=fig, hspace=0.55, wspace=0.38)

# ═══ Row 0 — Throughput ══════════════════════════════════════════════════════
nr = load("num_requests.json")
ax_tp_lat = fig.add_subplot(gs[0, 0])
ax_tp_rps = fig.add_subplot(gs[0, 1])

if nr:
    rest = nr.get("rest", {})
    grpc = nr.get("grpc", {})
    pcts      = ["p50", "p90", "p95", "p99"]
    rest_lats = [rest.get(f"{p}_ms") or 0 for p in pcts]
    grpc_lats = [grpc.get(f"{p}_ms") or 0 for p in pcts]
    bar_group(ax_tp_lat, ["p50", "p90", "p95", "p99"], rest_lats, grpc_lats,
              "Latency (ms)", "Throughput — Latency Percentiles (20 VUs × 30 s)")

    rps_vals = [rest.get("rps") or 0, grpc.get("rps") or 0]
    req_vals = [rest.get("total_requests") or 0, grpc.get("total_requests") or 0]
    x = np.arange(2)
    ax_tp_rps.bar(x, rps_vals, 0.4, color=[REST_COLOR, GRPC_COLOR], zorder=3)
    ax_tp_rps.set_xticks(x); ax_tp_rps.set_xticklabels(["REST", "gRPC"])
    ax_tp_rps.set_ylabel("Requests / second", fontsize=9)
    ax_tp_rps.set_title("Throughput — Requests/sec (20 VUs × 30 s)", fontsize=11, fontweight="bold", pad=8)
    for i, (v, r) in enumerate(zip(rps_vals, req_vals)):
        ax_tp_rps.text(i, v + max(rps_vals, default=1) * 0.02,
                       f"{v:.1f} RPS\n({int(r)} total)", ha="center", va="bottom", fontsize=8)
else:
    for ax in (ax_tp_lat, ax_tp_rps):
        ax.text(0.5, 0.5, "num_requests.json\nnot found", ha="center", va="center", transform=ax.transAxes)

# ═══ Row 1 — Payload size ════════════════════════════════════════════════════
ps = load("payload_size.json")
ax_ps_avg = fig.add_subplot(gs[1, 0])
ax_ps_p95 = fig.add_subplot(gs[1, 1])

if ps:
    sizes       = list(ps["sizes"].keys())
    size_labels = [s.upper() for s in sizes]
    rest_avgs   = [ps["sizes"][s]["rest"]["avg_ms"] if ps["sizes"][s]["rest"] else 0 for s in sizes]
    grpc_avgs   = [ps["sizes"][s]["grpc"]["avg_ms"] if ps["sizes"][s]["grpc"] else 0 for s in sizes]
    rest_p95s   = [ps["sizes"][s]["rest"]["p95_ms"] if ps["sizes"][s]["rest"] else 0 for s in sizes]
    grpc_p95s   = [ps["sizes"][s]["grpc"]["p95_ms"] if ps["sizes"][s]["grpc"] else 0 for s in sizes]
    bar_group(ax_ps_avg, size_labels, rest_avgs, grpc_avgs, "Avg Latency (ms)", "Payload Size — Avg Latency (10 VUs)")
    bar_group(ax_ps_p95, size_labels, rest_p95s, grpc_p95s, "p95 Latency (ms)", "Payload Size — p95 Latency (10 VUs)")
else:
    for ax in (ax_ps_avg, ax_ps_p95):
        ax.text(0.5, 0.5, "payload_size.json\nnot found", ha="center", va="center", transform=ax.transAxes)

# ═══ Row 2 — Concurrency ═════════════════════════════════════════════════════
par = load("parallel.json")
ax_par_lat = fig.add_subplot(gs[2, 0])
ax_par_p99 = fig.add_subplot(gs[2, 1])

if par:
    vu_keys   = list(par["vu_levels"].keys())
    vu_nums   = [int(k.replace("vu", "")) for k in vu_keys]
    rest_avgs_p, grpc_avgs_p, rest_p99s, grpc_p99s = [], [], [], []
    for k in vu_keys:
        rd = par["vu_levels"][k]["rest"]
        gd = par["vu_levels"][k]["grpc"]
        rest_avgs_p.append(rd["avg_ms"] if rd else 0)
        grpc_avgs_p.append(gd["avg_ms"] if gd else 0)
        rest_p99s.append(rd["p99_ms"] if rd else 0)
        grpc_p99s.append(gd["p99_ms"] if gd else 0)
    line_plot(ax_par_lat, vu_nums, rest_avgs_p, grpc_avgs_p,
              "Concurrent VUs", "Avg Latency (ms)", "Concurrency — Avg Latency vs VUs", x_log=True)
    line_plot(ax_par_p99, vu_nums, rest_p99s, grpc_p99s,
              "Concurrent VUs", "p99 Latency (ms)", "Concurrency — p99 Tail Latency vs VUs", x_log=True)
else:
    for ax in (ax_par_lat, ax_par_p99):
        ax.text(0.5, 0.5, "parallel.json\nnot found", ha="center", va="center", transform=ax.transAxes)

# ═══ Row 3 — Serialization isolation ════════════════════════════════════════
# This panel shows the impact of JSON.stringify+parse vs protobuf encode+decode
# on a STRUCTURED payload (nested objects, arrays, numbers) — the realistic case.
sr = load("serialization.json")
ax_sr_avg = fig.add_subplot(gs[3, 0])
ax_sr_p95 = fig.add_subplot(gs[3, 1])

if sr:
    size_labels_sr = list(sr["sizes"].keys())     # ["small","medium","large","xlarge"]
    mc_labels      = [f"{s}\n({sr['sizes'][s]['metric_count']} metrics)" for s in size_labels_sr]
    rest_avgs_sr   = [sr["sizes"][s]["rest"]["avg_ms"] if sr["sizes"][s]["rest"] else 0 for s in size_labels_sr]
    grpc_avgs_sr   = [sr["sizes"][s]["grpc"]["avg_ms"] if sr["sizes"][s]["grpc"] else 0 for s in size_labels_sr]
    rest_p95s_sr   = [sr["sizes"][s]["rest"]["p95_ms"] if sr["sizes"][s]["rest"] else 0 for s in size_labels_sr]
    grpc_p95s_sr   = [sr["sizes"][s]["grpc"]["p95_ms"] if sr["sizes"][s]["grpc"] else 0 for s in size_labels_sr]

    bar_group(ax_sr_avg, mc_labels, rest_avgs_sr, grpc_avgs_sr, "Avg Latency (ms)",
              "Serialization Impact — Avg Latency\n(structured payload: JSON.stringify+parse vs proto encode+decode)")
    bar_group(ax_sr_p95, mc_labels, rest_p95s_sr, grpc_p95s_sr, "p95 Latency (ms)",
              "Serialization Impact — p95 Latency\n(structured payload: JSON.stringify+parse vs proto encode+decode)")

    # Add annotation explaining what's being measured
    note = ("Payload = nested object: id, source, timestamp, priority,\n"
            "metrics[] (name+value+unit), address, tags map.\n"
            "JSON must transmit every field name as text; proto uses field numbers.")
    ax_sr_avg.text(0.01, 0.97, note, transform=ax_sr_avg.transAxes,
                   fontsize=7, va="top", color="grey",
                   bbox=dict(boxstyle="round,pad=0.3", facecolor="lightyellow", alpha=0.8))
else:
    for ax in (ax_sr_avg, ax_sr_p95):
        ax.text(0.5, 0.5, "serialization.json\nnot found\nRun: k6 run k6/test_serialization.js",
                ha="center", va="center", transform=ax.transAxes, fontsize=9)

# ─── Save ─────────────────────────────────────────────────────────────────────
out_path = OUT_DIR / "comparison_report.png"
fig.savefig(out_path, dpi=150, bbox_inches="tight")
print(f"\n✅  Chart saved → {out_path}")
plt.show()
