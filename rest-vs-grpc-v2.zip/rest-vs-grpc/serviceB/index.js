const express = require("express");
const grpc = require("@grpc/grpc-js");
const protoLoader = require("@grpc/proto-loader");
const path = require("path");

// ─────────────────────────────────────────────
// Shared processing logic
// Works with the STRUCTURED payload: id, metrics[], address, tags, etc.
// Serialization cost (JSON.parse on REST side, proto decode on gRPC side)
// is already paid by the time this function is called — that's by design.
// ─────────────────────────────────────────────
function processData(req) {
  const start = process.hrtime.bigint();
  const id = req.id || "unknown";

  // Simulate real work: hash every metric value
  let hash = 0;
  const metrics = req.metrics || [];
  for (const m of metrics) {
    const v = typeof m.value === "number" ? m.value : parseFloat(m.value) || 0;
    hash = ((hash << 5) - hash + Math.round(v * 1000)) | 0;
  }
  // Also fold in address fields
  const addr = req.address || {};
  for (const field of [addr.city, addr.country, addr.zip]) {
    for (let i = 0; i < (field || "").length; i++) {
      hash = ((hash << 5) - hash + (field.charCodeAt(i))) | 0;
    }
  }

  const processingMs = Number(process.hrtime.bigint() - start) / 1e6;

  return {
    id,
    result        : `processed-${Math.abs(hash).toString(16)}`,
    processed_at  : Date.now(),
    bytes_received: metrics.length,
    processing_ms : processingMs,
  };
}

// ─────────────────────────────────────────────
// REST server (port 3001)
// Express json() middleware calls JSON.parse() on every incoming request body.
// That parse cost is measured as part of the total ServiceA→ServiceB latency.
// ─────────────────────────────────────────────
function startRestServer() {
  const app = express();
  app.use(express.json({ limit: "50mb" }));

  app.post("/process", (req, res) => {
    const result = processData(req.body);
    res.json(result);
  });

  app.get("/health", (_req, res) => res.json({ status: "ok", protocol: "REST" }));

  app.listen(3001, () => {
    console.log("[ServiceB] REST server listening on port 3001");
  });
}

// ─────────────────────────────────────────────
// gRPC server (port 50051)
// The grpc library calls protobuf.decode() on the incoming binary frame.
// That decode cost replaces JSON.parse and is measured in the same latency window.
// ─────────────────────────────────────────────
function startGrpcServer() {
  const PROTO_PATH = path.join(__dirname, "proto", "service.proto");
  const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
    keepCase: true,
    longs: String,
    enums: String,
    defaults: true,
    oneofs: true,
  });
  const proto = grpc.loadPackageDefinition(packageDefinition).dataservice;

  const server = new grpc.Server({
    "grpc.max_receive_message_length": 50 * 1024 * 1024,
    "grpc.max_send_message_length"   : 50 * 1024 * 1024,
  });

  server.addService(proto.DataService.service, {
    ProcessData: (call, callback) => {
      // call.request is already the decoded proto object
      const result = processData(call.request);
      callback(null, result);
    },
  });

  server.bindAsync(
    "0.0.0.0:50051",
    grpc.ServerCredentials.createInsecure(),
    (err, port) => {
      if (err) { console.error("[ServiceB] gRPC bind error:", err); return; }
      console.log(`[ServiceB] gRPC server listening on port ${port}`);
    }
  );
}

startRestServer();
startGrpcServer();
