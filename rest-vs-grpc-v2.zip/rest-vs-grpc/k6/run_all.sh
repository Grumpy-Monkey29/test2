#!/usr/bin/env bash
# run_all.sh — Run all four k6 performance tests in sequence.
# Execute from the project root: bash k6/run_all.sh

set -e

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
RESULTS_DIR="$ROOT/results"
mkdir -p "$RESULTS_DIR"

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║       REST vs gRPC — k6 Performance Test Suite          ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo "Make sure ServiceA (port 3000) and ServiceB (3001 / 50051) are running."
echo ""

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "TEST 1 of 4 — Throughput  (20 VUs × 30 s)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
k6 run "$ROOT/k6/test_num_requests.js"
sleep 3

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "TEST 2 of 4 — Payload size  (1 KB → 500 KB, 10 VUs × 20 s each)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
k6 run "$ROOT/k6/test_payload_size.js"
sleep 3

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "TEST 3 of 4 — Concurrency  (1 → 100 VUs, 15 s each level)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
k6 run "$ROOT/k6/test_parallel.js"
sleep 3

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "TEST 4 of 4 — Serialization  (structured payload, JSON vs Protobuf)"
echo "   Measures JSON.stringify+parse vs protobuf.encode+decode"
echo "   on a realistic nested object (metrics[], address, tags)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
k6 run "$ROOT/k6/test_serialization.js"

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  All tests complete! Results in ./results/               ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo "  num_requests.json   — throughput"
echo "  payload_size.json   — flat payload sizes"
echo "  parallel.json       — concurrency"
echo "  serialization.json  — JSON.stringify+parse vs proto encode+decode"
echo ""
echo "Plot the results:"
echo "  python plot/plot_results.py"
echo ""
