/**
 * k6/utils.js
 * Shared helpers for extracting metrics per protocol tag from k6 summary data.
 */

/**
 * Pull the key percentiles + rate out of a tagged metric group.
 * k6 exposes tagged sub-metrics as  "metric_name{tag:value}"
 *
 * @param {object} metrics  - data.metrics from handleSummary
 * @param {string} tag      - e.g. "rest" or "grpc"
 */
export function extractMetrics(metrics, tag) {
  const dur = metrics[`http_req_duration{protocol:${tag}}`];
  const reqs = metrics[`http_reqs{protocol:${tag}}`];
  const failed = metrics[`http_req_failed{protocol:${tag}}`];

  if (!dur) return null;

  return {
    avg_ms: round(dur.values.avg),
    min_ms: round(dur.values.min),
    max_ms: round(dur.values.max),
    p50_ms: round(dur.values["p(50)"]),
    p90_ms: round(dur.values["p(90)"]),
    p95_ms: round(dur.values["p(95)"]),
    p99_ms: round(dur.values["p(99)"]),
    total_requests: reqs ? reqs.values.count : 0,
    rps: reqs ? round(reqs.values.rate) : 0,
    error_rate: failed ? round(failed.values.rate * 100) : 0,
  };
}

function round(v) {
  return v !== undefined ? Math.round(v * 1000) / 1000 : null;
}

/**
 * Generate a string payload of exactly `kb` kilobytes.
 */
export function makePayload(kb) {
  const targetBytes = kb * 1024;
  // Repeating ASCII chunk
  const chunk = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-";
  let s = "";
  while (Buffer.byteLength(s, "utf8") < targetBytes) {
    s += chunk;
  }
  return s.slice(0, targetBytes);
}
