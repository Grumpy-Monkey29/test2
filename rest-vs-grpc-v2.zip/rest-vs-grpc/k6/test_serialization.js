/**
 * test_serialization.js
 *
 * Isolates the serialization cost by measuring the same structured
 * payload at different sizes, across both protocols.
 *
 * metric_count controls payload complexity:
 *   10   metrics ≈ 1 KB  JSON  (proto is ~30% smaller)
 *   100  metrics ≈ 8 KB  JSON  (proto is ~40% smaller)
 *   500  metrics ≈ 40 KB JSON  (proto is ~45% smaller)
 *   2000 metrics ≈ 160KB JSON  (proto is ~50% smaller)
 *
 * Run:
 *   k6 run k6/test_serialization.js
 */

import http from "k6/http";
import { check } from "k6";
import { Trend, Counter } from "k6/metrics";

const SIZES = [
  { label: "small",  metric_count: 10   },   // ~1 KB
  { label: "medium", metric_count: 100  },   // ~8 KB
  { label: "large",  metric_count: 500  },   // ~40 KB
  { label: "xlarge", metric_count: 2000 },   // ~160 KB
];
const PROTOCOLS = ["rest", "grpc"];

// Custom metrics
const metrics = {};
for (const proto of PROTOCOLS) {
  for (const { label } of SIZES) {
    const key = `${proto}_${label}`;
    metrics[`${key}_duration`] = new Trend(`${key}_duration`, true);
    metrics[`${key}_errors`]   = new Counter(`${key}_errors`);
  }
}

// ─── Scenarios: 8 VUs × 15s each, sequential ─────────────────────────────────
export const options = { scenarios: {}, thresholds: {} };
let offset = 0;
for (const proto of PROTOCOLS) {
  for (const { label } of SIZES) {
    const key = `${proto}_${label}`;
    options.scenarios[key] = {
      executor : "constant-vus",
      vus      : 8,
      duration : "15s",
      startTime: `${offset}s`,
      exec     : `exec_${key}`,
      tags     : { protocol: proto, size: label },
    };
    options.thresholds[`${key}_duration`] = ["p(95)<10000"];
    offset += 17;
  }
}

// ─── Executor functions ───────────────────────────────────────────────────────
const BASE_URL = "http://localhost:3000";
const HEADERS  = { "Content-Type": "application/json" };

function makeCall(proto, metricCount, label) {
  const body = JSON.stringify({ metric_count: metricCount });
  const res  = http.post(`${BASE_URL}/${proto}/call`, body,
    { headers: HEADERS, tags: { protocol: proto, size: label } });

  const key = `${proto}_${label}`;
  const ok  = check(res, { [`${proto}/${label} → 200`]: (r) => r.status === 200 });
  if (!ok) metrics[`${key}_errors`].add(1);
  metrics[`${key}_duration`].add(res.timings.duration);
}

export const exec_rest_small  = () => makeCall("rest",  10,   "small");
export const exec_rest_medium = () => makeCall("rest",  100,  "medium");
export const exec_rest_large  = () => makeCall("rest",  500,  "large");
export const exec_rest_xlarge = () => makeCall("rest",  2000, "xlarge");
export const exec_grpc_small  = () => makeCall("grpc",  10,   "small");
export const exec_grpc_medium = () => makeCall("grpc",  100,  "medium");
export const exec_grpc_large  = () => makeCall("grpc",  500,  "large");
export const exec_grpc_xlarge = () => makeCall("grpc",  2000, "xlarge");

// ─── Summary → results/serialization.json ────────────────────────────────────
export function handleSummary(data) {
  const result = {
    test : "serialization",
    note : "Structured payload (nested objects, arrays, numbers). metric_count drives size.",
    sizes: {},
  };

  for (const { label, metric_count } of SIZES) {
    result.sizes[label] = { metric_count, rest: null, grpc: null };
    for (const proto of PROTOCOLS) {
      const key = `${proto}_${label}`;
      const m   = data.metrics[`${key}_duration`];
      if (m) {
        result.sizes[label][proto] = {
          avg_ms: round(m.values.avg),
          min_ms: round(m.values.min),
          max_ms: round(m.values.max),
          p50_ms: round(m.values["p(50)"]),
          p90_ms: round(m.values["p(90)"]),
          p95_ms: round(m.values["p(95)"]),
          p99_ms: round(m.values["p(99)"]),
        };
      }
    }
  }

  return {
    "results/serialization.json": JSON.stringify(result, null, 2),
    stdout: "\n✅  Results written to results/serialization.json\n",
  };
}

function round(v) {
  return v !== undefined ? Math.round(v * 100) / 100 : null;
}
