/**
 * payload.js  (used by both ServiceA and k6 scripts)
 *
 * Generates a STRUCTURED payload (nested objects, arrays, mixed types)
 * that reflects real-world service communication. The size is controlled
 * by the number of metric entries in the array.
 *
 * This is intentional: flat string repetition is the worst-case scenario
 * for showing Protobuf's advantage. Realistic structured data — where JSON
 * must repeat field names as strings and serialize every number as text —
 * is where the serialization cost difference actually appears.
 */

const CITIES    = ["New York", "London", "Tokyo", "Sydney", "Berlin"];
const COUNTRIES = ["US", "GB", "JP", "AU", "DE"];
const UNITS     = ["ms", "bytes", "rpm", "°C", "rps", "MB", "%"];
const SOURCES   = ["api-gateway", "worker", "scheduler", "webhook", "stream"];

/**
 * Build a structured request body.
 * @param {string} id
 * @param {number} metricCount  - controls approximate payload size
 *   ~10  metrics ≈ 1 KB JSON
 *   ~100 metrics ≈ 8 KB JSON
 *   ~500 metrics ≈ 40 KB JSON
 *   ~2000 metrics ≈ 160 KB JSON
 */
function buildPayload(id, metricCount = 10) {
  const metrics = [];
  for (let i = 0; i < metricCount; i++) {
    metrics.push({
      name : `metric_${i}_${UNITS[i % UNITS.length]}`,
      value: parseFloat((Math.random() * 10000).toFixed(4)),
      unit : UNITS[i % UNITS.length],
    });
  }

  return {
    id,
    source   : SOURCES[metricCount % SOURCES.length],
    timestamp: Date.now(),
    priority : (metricCount % 5) + 1,
    is_urgent: metricCount > 500,
    metrics,
    address: {
      street : `${metricCount} Performance Blvd`,
      city   : CITIES[metricCount % CITIES.length],
      country: COUNTRIES[metricCount % COUNTRIES.length],
      zip    : `${10000 + (metricCount % 90000)}`,
    },
    tags: {
      env    : "benchmark",
      version: "2.0",
      run_id : id,
    },
  };
}

/**
 * Map a target KB size to an approximate metric count.
 * These are tuned for the JSON representation size.
 */
function metricCountForKb(kb) {
  if (kb <= 1)   return 10;
  if (kb <= 10)  return 100;
  if (kb <= 100) return 500;
  return 2000;  // ~160 KB
}

module.exports = { buildPayload, metricCountForKb };
