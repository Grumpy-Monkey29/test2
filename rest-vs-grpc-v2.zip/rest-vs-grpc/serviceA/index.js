const express = require("express");
const axios   = require("axios");
const grpc    = require("@grpc/grpc-js");
const protoLoader = require("@grpc/proto-loader");
const path    = require("path");
const { buildPayload } = require("./payload");

const SERVICE_B_REST      = "http://localhost:3001";
const SERVICE_B_GRPC_HOST = "localhost:50051";

// ─────────────────────────────────────────────
// gRPC client — singleton, reused across all requests.
// HTTP/2 multiplexing means one connection handles many concurrent RPCs.
// ─────────────────────────────────────────────
const PROTO_PATH = path.join(__dirname, "proto", "service.proto");
const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs   : String,
  enums   : String,
  defaults: true,
  oneofs  : true,
});
const proto = grpc.loadPackageDefinition(packageDefinition).dataservice;

const grpcClient = new proto.DataService(
  SERVICE_B_GRPC_HOST,
  grpc.credentials.createInsecure(),
  {
    "grpc.max_receive_message_length": 50 * 1024 * 1024,
    "grpc.max_send_message_length"   : 50 * 1024 * 1024,
  }
);

function grpcProcessData(requestData) {
  return new Promise((resolve, reject) => {
    grpcClient.ProcessData(requestData, (err, response) => {
      if (err) return reject(err);
      resolve(response);
    });
  });
}

// ─────────────────────────────────────────────
// Express App
// ─────────────────────────────────────────────
const app = express();
app.use(express.json({ limit: "50mb" }));

/**
 * POST /rest/call
 * Body: { metric_count: number }   (controls payload size)
 *
 * Timeline of serialization work:
 *   1. buildPayload()          → JS object (in memory)
 *   2. JSON.stringify (axios)  → UTF-8 string on the wire  ← measured
 *   3. HTTP/1.1 transport                                   ← measured
 *   4. JSON.parse (Express B)  → JS object                 ← measured
 *   5. processData()           → response object
 *   6. JSON.stringify (res.json) → response on the wire    ← measured
 *   7. JSON.parse (axios resp) → JS object                 ← measured
 */
app.post("/rest/call", async (req, res) => {
  const start = process.hrtime.bigint();
  try {
    const metricCount = req.body.metric_count || 10;
    const id          = `rest-${__filename}-${Date.now()}`;
    const payload     = buildPayload(id, metricCount);

    const response = await axios.post(
      `${SERVICE_B_REST}/process`,
      payload,   // axios calls JSON.stringify() here
      { headers: { "Content-Type": "application/json" } }
    );

    const durationMs = Number(process.hrtime.bigint() - start) / 1e6;
    res.json({ protocol: "REST", duration_ms: durationMs, service_b_response: response.data });
  } catch (err) {
    const durationMs = Number(process.hrtime.bigint() - start) / 1e6;
    res.status(500).json({ protocol: "REST", error: err.message, duration_ms: durationMs });
  }
});

/**
 * POST /grpc/call
 * Body: { metric_count: number }   (controls payload size)
 *
 * Timeline of serialization work:
 *   1. buildPayload()              → JS object (in memory)
 *   2. protobuf.encode (grpc-js)   → binary frame on the wire  ← measured
 *   3. HTTP/2 transport                                          ← measured
 *   4. protobuf.decode (grpc-js B) → JS object                 ← measured
 *   5. processData()               → response object
 *   6. protobuf.encode (response)  → binary frame               ← measured
 *   7. protobuf.decode (grpc-js)   → JS object                 ← measured
 *
 * Key difference vs REST:
 *  - Binary frames are smaller than JSON text (especially for numbers/booleans)
 *  - Field names are NOT transmitted (replaced by field number tags)
 *  - HTTP/2 header compression (HPACK) vs repeated HTTP/1.1 headers
 */
app.post("/grpc/call", async (req, res) => {
  const start = process.hrtime.bigint();
  try {
    const metricCount = req.body.metric_count || 10;
    const id          = `grpc-${__filename}-${Date.now()}`;
    const payload     = buildPayload(id, metricCount);

    const response = await grpcProcessData(payload);

    const durationMs = Number(process.hrtime.bigint() - start) / 1e6;
    res.json({ protocol: "gRPC", duration_ms: durationMs, service_b_response: response });
  } catch (err) {
    const durationMs = Number(process.hrtime.bigint() - start) / 1e6;
    res.status(500).json({ protocol: "gRPC", error: err.message, duration_ms: durationMs });
  }
});

app.get("/health", (_req, res) => res.json({ status: "ok" }));

app.listen(3000, () => {
  console.log("[ServiceA] Listening on port 3000");
  console.log("  POST /rest/call  { metric_count: N }  → ServiceB via REST (JSON.stringify + JSON.parse)");
  console.log("  POST /grpc/call  { metric_count: N }  → ServiceB via gRPC (protobuf.encode + decode)");
});
