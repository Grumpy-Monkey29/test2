# REST vs gRPC Performance Comparison

A self-contained Node.js benchmark comparing REST (HTTP/1.1 + JSON) against
gRPC (HTTP/2 + Protobuf) across three dimensions: throughput, payload size,
and concurrency. Results are captured to JSON files and visualised with Python.

```
┌─────────────────────────────────────────────────────┐
│  k6 load generator                                  │
│      │  POST /rest/call  ──►  ServiceA  ──REST──►  ServiceB :3001
│      │  POST /grpc/call  ──►  ServiceA  ──gRPC──►  ServiceB :50051
└─────────────────────────────────────────────────────┘
```

---

## Project structure

```
rest-vs-grpc/
├── serviceA/          # Caller service  (port 3000)
│   ├── index.js
│   ├── package.json
│   └── proto/service.proto
├── serviceB/          # Backend service  (REST :3001 | gRPC :50051)
│   ├── index.js
│   ├── package.json
│   └── proto/service.proto
├── k6/
│   ├── test_num_requests.js   # Test 1 — throughput
│   ├── test_payload_size.js   # Test 2 — payload sizes
│   ├── test_parallel.js       # Test 3 — concurrency
│   └── run_all.sh             # Run all three tests
├── results/           # JSON output (auto-created)
└── plot/
    └── plot_results.py
```

---

## Prerequisites

| Tool | Install |
|------|---------|
| Node.js ≥ 18 | https://nodejs.org |
| k6 | https://k6.io/docs/get-started/installation/ |
| Python ≥ 3.9 + pip | https://python.org |

---

## Quick start

### 1. Install Node dependencies

```bash
cd serviceB && npm install && cd ..
cd serviceA && npm install && cd ..
```

### 2. Start ServiceB (leave running in terminal 1)

```bash
cd serviceB
node index.js
# [ServiceB] REST server listening on port 3001
# [ServiceB] gRPC server listening on port 50051
```

### 3. Start ServiceA (leave running in terminal 2)

```bash
cd serviceA
node index.js
# [ServiceA] Listening on port 3000
```

### 4. Quick smoke-test (optional)

```bash
# REST path
curl -s -X POST http://localhost:3000/rest/call \
  -H "Content-Type: application/json" \
  -d '{"id":"smoke","payload":"hello","payload_size_kb":0}' | jq .

# gRPC path
curl -s -X POST http://localhost:3000/grpc/call \
  -H "Content-Type: application/json" \
  -d '{"id":"smoke","payload":"hello","payload_size_kb":0}' | jq .
```

### 5. Run all k6 tests (terminal 3, from project root)

```bash
chmod +x k6/run_all.sh
bash k6/run_all.sh
```

Results are written to `results/`:

| File | Contents |
|------|----------|
| `num_requests.json` | Throughput: RPS, latency percentiles |
| `payload_size.json` | Latency vs payload size (1KB→500KB) |
| `parallel.json` | Latency vs concurrency (1→100 VUs) |

### 6. Plot the results

```bash
pip install matplotlib numpy
python plot/plot_results.py
# Opens an interactive window + saves results/comparison_report.png
```

---

## What each test measures

### Test 1 — Throughput (`test_num_requests.js`)
- **20 VUs each** for REST and gRPC, running for **30 seconds**
- Measures: RPS, p50/p90/p95/p99 latency, total request count
- Fixed 1 KB payload

### Test 2 — Payload size (`test_payload_size.js`)
- **10 VUs**, **20 s per size level**
- Payload sizes: **1 KB, 10 KB, 100 KB, 500 KB**
- Shows where Protobuf binary encoding gives gRPC an advantage over JSON

### Test 3 — Concurrency (`test_parallel.js`)
- **15 s per VU level**
- VU levels: **1, 5, 20, 50, 100**
- Measures tail latency as connection pressure grows

---

## Key architectural notes

- **gRPC client in ServiceA is a singleton** — it reuses a single HTTP/2 connection with multiplexed streams, matching real-world usage.
- **REST uses a new TCP connection per request** (default axios behaviour), making the REST↔gRPC comparison fair at the protocol level.
- ServiceB performs identical CPU work for both protocols, isolating protocol overhead.
