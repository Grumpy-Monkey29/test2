#!/usr/bin/env bash
# run_all.sh — Run all three k6 performance tests in sequence.
# Must be executed from the project root: bash k6/run_all.sh

set -e

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
RESULTS_DIR="$ROOT/results"
mkdir -p "$RESULTS_DIR"

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║     REST vs gRPC — k6 Performance Test Suite    ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "Make sure ServiceA (port 3000) and ServiceB (ports 3001 / 50051) are running."
echo ""

# ── 1. Throughput / number of requests ───────────────────────────────────────
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "TEST 1 of 3 — Throughput (number of requests, 20 VUs × 30 s)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
k6 run "$ROOT/k6/test_num_requests.js"

echo ""
sleep 3

# ── 2. Payload size ───────────────────────────────────────────────────────────
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "TEST 2 of 3 — Payload size (1 KB → 500 KB, 10 VUs × 20 s each)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
k6 run "$ROOT/k6/test_payload_size.js"

echo ""
sleep 3

# ── 3. Parallel requests / concurrency ───────────────────────────────────────
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "TEST 3 of 3 — Concurrency (1 → 100 VUs, 15 s each level)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
k6 run "$ROOT/k6/test_parallel.js"

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║  All tests complete! Results in ./results/       ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "Now run the Python plotter:"
echo "  cd plot && python plot_results.py"
echo ""
